# BioPulse AI — Industrial Intelligence Platform

A senior-grade full-stack dashboard for biomass co-generation plant monitoring, built with React.

## Tech Stack
- **React 18** — Component architecture
- **Recharts** — Data visualization
- **Anthropic API** — AI diagnostics & chatbot
- **CSS Variables** — Design system theming

## Modules
1. **Live Overview** — Real-time sensor telemetry with animated charts and gauges
2. **Digital Twin** — SVG plant visualization with animated flow pipes and components
3. **Predictive Maintenance** — ML model cards + live AI diagnosis via Anthropic API
4. **Industrial AI Assistant** — Plant-aware chatbot powered by Claude
5. **Supply Chain** — Vendor dashboard, biomass logistics, delivery tracking
6. **Carbon Analytics** — ESG dashboard with CO₂, stubble fire prevention, credit estimation
7. **Forecasting** — 7-day production outlook for ethanol, power, and biomass demand

## Setup

```bash
npm install
npm start
```

## Environment
The app calls `https://api.anthropic.com/v1/messages` directly from the browser.
For production, proxy requests through a backend to protect your API key.

Add your Anthropic API key handling in a backend proxy (FastAPI recommended).

## Design System
- Font: DM Sans (body) + DM Mono (data) + Playfair Display (headings)
- Color: Dark ink base (#0d1117) with amber (#e8a24b), teal (#4ecdc4), jade (#52b788) accents
- All colors via CSS variables for easy theming

## Recommended Backend (FastAPI)
```python
from fastapi import FastAPI
import anthropic, os

app = FastAPI()
client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

@app.post("/api/diagnose")
async def diagnose(payload: dict):
    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1000,
        messages=payload["messages"]
    )
    return {"content": message.content}
```
