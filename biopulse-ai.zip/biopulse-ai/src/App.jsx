import React, { useState } from 'react';
import './index.css';
import LoginScreen from './pages/LoginScreen';
import Dashboard from './pages/Dashboard';

export default function App() {
  const [authenticated, setAuthenticated] = useState(false);
  const [user, setUser] = useState(null);

  const handleLogin = (userData) => {
    setUser(userData);
    setAuthenticated(true);
  };

  const handleLogout = () => {
    setAuthenticated(false);
    setUser(null);
  };

  return authenticated
    ? <Dashboard user={user} onLogout={handleLogout} />
    : <LoginScreen onLogin={handleLogin} />;
}
