import React, { useState } from 'react';

const MODELS = [
  { name: 'Random Forest', acc: 88.4, status: 'Normal', confidence: 'High', color: 'var(--sky)' },
  { name: 'Neural Network (ANN)', acc: 91.2, status: 'Normal', confidence: 'High', color: 'var(--teal)' },
  { name: 'Gradient Boosting', acc: 94.7, status: 'Warning', confidence: 'Very High', color: 'var(--amber)' },
  { name: 'TPOT AutoML', acc: 99.69, status: 'Normal', confidence: 'Extreme', color: 'var(--jade)' },
];

export default function PredictiveMaintenance({ data }) {
  const [form, setForm] = useState({
    boilerTemp: data.boilerTemp.toFixed(1),
    steamPressure: data.steamPressure.toFixed(1),
    turbineOutput: data.turbineOutput.toFixed(0),
    vibration: '0.45',
    espEfficiency: data.espEfficiency.toFixed(1),
  });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const runDiagnosis = async () => {
    setLoading(true);
    setResult(null);
    try {
      const resp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: `You are an industrial AI diagnostics engine for a biomass co-generation plant. 
Analyze sensor readings and return a JSON object ONLY with these exact keys:
{
  "riskLevel": "Low|Medium|High|Critical",
  "failureProbability": number (0-100),
  "diagnosis": "brief 2-sentence diagnosis",
  "rootCause": "most likely root cause",
  "atRiskComponents": ["list", "of", "components"],
  "recommendedAction": "brief recommended action",
  "timeToFailure": "estimated time or N/A"
}
Return ONLY the JSON. No markdown, no preamble.`,
          messages: [{
            role: 'user',
            content: `Sensor data: Boiler Temp: ${form.boilerTemp}°C | Steam Pressure: ${form.steamPressure} bar | Turbine Output: ${form.turbineOutput} kW | Vibration: ${form.vibration} mm/s | ESP Efficiency: ${form.espEfficiency}%. Analyze for failure risk.`
          }]
        })
      });
      const d = await resp.json();
      const text = d.content?.[0]?.text || '{}';
      const parsed = JSON.parse(text.replace(/```json|```/g, '').trim());
      setResult(parsed);
    } catch (e) {
      setResult({ riskLevel: 'Error', diagnosis: 'API call failed. Check your connection.', failureProbability: 0, rootCause: 'N/A', atRiskComponents: [], recommendedAction: 'Retry', timeToFailure: 'N/A' });
    }
    setLoading(false);
  };

  const riskColor = (r) => ({ Low: 'var(--jade)', Medium: 'var(--amber)', High: 'var(--rose)', Critical: 'var(--rose)', Error: 'var(--text-3)' }[r] || 'var(--text)');

  return (
    <div>
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 22, fontWeight: 400, fontFamily: 'var(--font-display)', color: 'var(--text)', marginBottom: 2 }}>Predictive Maintenance</h1>
        <div style={{ fontSize: 12, color: 'var(--text-3)' }}>ML model ensemble + AI-powered real-time failure diagnosis</div>
      </div>

      {/* Model cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 20 }}>
        {MODELS.map(m => (
          <div key={m.name} style={{
            background: 'var(--ink-2)', border: '1px solid var(--border)',
            borderRadius: 14, padding: '18px 16px', position: 'relative', overflow: 'hidden',
          }}>
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: m.color, borderRadius: '14px 14px 0 0' }} />
            <div style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', marginBottom: 12 }}>{m.name.toUpperCase()}</div>
            <div style={{ fontSize: 26, fontWeight: 300, color: m.color, fontFamily: 'var(--font-display)', marginBottom: 4 }}>{m.acc}%</div>
            <div style={{ fontSize: 10, color: 'var(--text-3)', marginBottom: 8 }}>Accuracy</div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{
                fontSize: 9, padding: '2px 7px', borderRadius: 4,
                background: m.status === 'Normal' ? 'var(--jade-dim)' : 'var(--amber-dim)',
                color: m.status === 'Normal' ? 'var(--jade)' : 'var(--amber)',
                fontFamily: 'var(--font-mono)',
              }}>{m.status.toUpperCase()}</span>
              <span style={{ fontSize: 10, color: 'var(--text-3)' }}>{m.confidence}</span>
            </div>
            {/* Accuracy bar */}
            <div style={{ marginTop: 10, height: 2, background: 'rgba(255,255,255,0.06)', borderRadius: 99 }}>
              <div style={{ height: '100%', width: `${m.acc}%`, background: m.color, borderRadius: 99 }} />
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Input form */}
        <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: 22 }}>
          <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 18 }}>
            LIVE SENSOR INPUT — AI DIAGNOSIS
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {[
              { key: 'boilerTemp', label: 'Boiler Temperature (°C)', placeholder: '312.0' },
              { key: 'steamPressure', label: 'Steam Pressure (bar)', placeholder: '18.4' },
              { key: 'turbineOutput', label: 'Turbine Output (kW)', placeholder: '2840' },
              { key: 'vibration', label: 'Vibration Level (mm/s)', placeholder: '0.45' },
              { key: 'espEfficiency', label: 'ESP Efficiency (%)', placeholder: '96.7' },
            ].map(f => (
              <label key={f.key} style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
                <span style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em' }}>{f.label}</span>
                <input
                  value={form[f.key]}
                  onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                  placeholder={f.placeholder}
                  style={{
                    background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)',
                    borderRadius: 8, padding: '9px 12px', color: 'var(--text)',
                    fontSize: 13, outline: 'none', fontFamily: 'var(--font-mono)',
                    transition: 'border-color 0.2s',
                  }}
                  onFocus={e => e.target.style.borderColor = 'rgba(232,162,75,0.4)'}
                  onBlur={e => e.target.style.borderColor = 'var(--border)'}
                />
              </label>
            ))}
            <button onClick={runDiagnosis} disabled={loading}
              style={{
                marginTop: 6, padding: '12px 18px', borderRadius: 9,
                background: loading ? 'rgba(232,162,75,0.4)' : 'var(--amber)',
                color: '#0d1117', fontWeight: 600, fontSize: 13,
                cursor: loading ? 'wait' : 'pointer', transition: 'var(--transition)',
                boxShadow: loading ? 'none' : '0 3px 14px var(--amber-glow)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}>
              {loading ? (
                <><span style={{ width: 12, height: 12, border: '2px solid rgba(13,17,23,0.4)', borderTopColor: '#0d1117', borderRadius: '50%', animation: 'spin-slow 0.7s linear infinite', display: 'inline-block' }} /> Running AI Diagnosis…</>
              ) : '▶ Run AI Diagnosis'}
            </button>
          </div>
        </div>

        {/* Result */}
        <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: 22 }}>
          <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 18 }}>
            DIAGNOSIS RESULT
          </div>
          {!result && !loading && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 300, gap: 12, color: 'var(--text-3)', textAlign: 'center' }}>
              <div style={{ fontSize: 32, opacity: 0.3 }}>◎</div>
              <div style={{ fontSize: 13 }}>Enter sensor values and run diagnosis</div>
              <div style={{ fontSize: 11, opacity: 0.6 }}>AI will analyze for failure risk, root causes, and recommendations</div>
            </div>
          )}
          {loading && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 300, gap: 16 }}>
              <div style={{ width: 48, height: 48, border: '3px solid var(--border)', borderTopColor: 'var(--amber)', borderRadius: '50%', animation: 'spin-slow 0.9s linear infinite' }} />
              <div style={{ fontSize: 13, color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>AI analyzing sensor data…</div>
            </div>
          )}
          {result && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14, animation: 'float-up 0.4s ease' }}>
              <div style={{ display: 'flex', gap: 12 }}>
                <div style={{
                  padding: '8px 14px', borderRadius: 8,
                  background: `${riskColor(result.riskLevel)}22`,
                  border: `1px solid ${riskColor(result.riskLevel)}44`,
                  flex: 1, textAlign: 'center',
                }}>
                  <div style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', marginBottom: 4 }}>RISK LEVEL</div>
                  <div style={{ fontSize: 18, fontWeight: 500, color: riskColor(result.riskLevel) }}>{result.riskLevel}</div>
                </div>
                <div style={{
                  padding: '8px 14px', borderRadius: 8,
                  background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)',
                  flex: 1, textAlign: 'center',
                }}>
                  <div style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', marginBottom: 4 }}>FAILURE PROB.</div>
                  <div style={{ fontSize: 18, fontWeight: 500, color: result.failureProbability > 50 ? 'var(--rose)' : 'var(--jade)' }}>{result.failureProbability}%</div>
                </div>
                <div style={{
                  padding: '8px 14px', borderRadius: 8,
                  background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)',
                  flex: 1, textAlign: 'center',
                }}>
                  <div style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', marginBottom: 4 }}>TIME TO FAIL</div>
                  <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--amber)' }}>{result.timeToFailure}</div>
                </div>
              </div>
              <div style={{ padding: '12px 14px', background: 'rgba(255,255,255,0.03)', borderRadius: 9, border: '1px solid var(--border)' }}>
                <div style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', marginBottom: 6 }}>DIAGNOSIS</div>
                <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.6 }}>{result.diagnosis}</div>
              </div>
              <div style={{ padding: '12px 14px', background: 'rgba(255,255,255,0.03)', borderRadius: 9, border: '1px solid var(--border)' }}>
                <div style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', marginBottom: 6 }}>ROOT CAUSE</div>
                <div style={{ fontSize: 13, color: 'var(--amber)' }}>{result.rootCause}</div>
              </div>
              {result.atRiskComponents?.length > 0 && (
                <div style={{ padding: '12px 14px', background: 'var(--rose-dim)', borderRadius: 9, border: '1px solid rgba(232,91,75,0.2)' }}>
                  <div style={{ fontSize: 10, color: 'var(--rose)', fontFamily: 'var(--font-mono)', marginBottom: 8 }}>AT-RISK COMPONENTS</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                    {result.atRiskComponents.map((c, i) => (
                      <span key={i} style={{ fontSize: 11, padding: '3px 9px', borderRadius: 5, background: 'rgba(232,91,75,0.15)', color: 'var(--rose)', fontFamily: 'var(--font-mono)' }}>{c}</span>
                    ))}
                  </div>
                </div>
              )}
              <div style={{ padding: '12px 14px', background: 'var(--jade-dim)', borderRadius: 9, border: '1px solid rgba(82,183,136,0.2)' }}>
                <div style={{ fontSize: 10, color: 'var(--jade)', fontFamily: 'var(--font-mono)', marginBottom: 6 }}>RECOMMENDED ACTION</div>
                <div style={{ fontSize: 13, color: 'var(--text-2)' }}>{result.recommendedAction}</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
