import React, { useState } from 'react';

const VENDORS = [
  { id: 1, name: 'Kisan Biomass Co.', location: 'Sirsa, HR', distance: '12 km', moisture: 14.2, stock: 420, status: 'On Route', eta: '2h 15m', qty: 45, reliability: 96 },
  { id: 2, name: 'Punjab Agro Feeds', location: 'Fatehabad, HR', distance: '18 km', moisture: 16.1, stock: 280, status: 'Delivered', eta: '—', qty: 60, reliability: 88 },
  { id: 3, name: 'Haryana Parali Ltd.', location: 'Hisar, HR', distance: '8 km', moisture: 13.8, stock: 610, status: 'Delayed', eta: '4h 30m', qty: 30, reliability: 72 },
  { id: 4, name: 'Green Agri Exports', location: 'Bhiwani, HR', distance: '22 km', moisture: 15.4, stock: 190, status: 'Scheduled', eta: '6h 00m', qty: 50, reliability: 91 },
];

const STATUS_COLOR = { 'On Route': 'var(--jade)', 'Delivered': 'var(--teal)', 'Delayed': 'var(--rose)', 'Scheduled': 'var(--amber)' };

export default function SupplyChain({ data }) {
  const [selected, setSelected] = useState(1);
  const vendor = VENDORS.find(v => v.id === selected);

  return (
    <div>
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 22, fontWeight: 400, fontFamily: 'var(--font-display)', color: 'var(--text)', marginBottom: 2 }}>Supply Chain</h1>
        <div style={{ fontSize: 12, color: 'var(--text-3)' }}>Biomass vendor tracking, inventory, and logistics analytics</div>
      </div>

      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 20 }}>
        {[
          { label: 'ACTIVE VENDORS', val: '4', sub: '20km radius', color: 'var(--amber)' },
          { label: 'DAILY INTAKE', val: '185', unit: 'T', sub: 'Today\'s delivery', color: 'var(--teal)' },
          { label: 'BIOMASS STOCK', val: '1,500', unit: 'T', sub: 'Current inventory', color: 'var(--jade)' },
          { label: 'AVG MOISTURE', val: '14.9', unit: '%', sub: 'Target: ≤15%', color: 'var(--sky)' },
        ].map(c => (
          <div key={c.label} style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: '18px 20px', position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: c.color, borderRadius: '14px 14px 0 0' }} />
            <div style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', marginBottom: 6 }}>{c.label}</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 3 }}>
              <span style={{ fontSize: 26, fontWeight: 300, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>{c.val}</span>
              {c.unit && <span style={{ fontSize: 12, color: 'var(--text-3)' }}>{c.unit}</span>}
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{c.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 16 }}>
        {/* Vendor table */}
        <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)', fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em' }}>
            VENDOR DASHBOARD
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'rgba(255,255,255,0.02)' }}>
                {['Vendor', 'Location', 'Dist.', 'Moisture', 'Stock (T)', 'Status', 'ETA'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', fontWeight: 400 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {VENDORS.map(v => (
                <tr key={v.id} onClick={() => setSelected(v.id)}
                  style={{
                    borderTop: '1px solid var(--border)', cursor: 'pointer',
                    background: selected === v.id ? 'rgba(232,162,75,0.06)' : 'transparent',
                    transition: 'background 0.15s',
                  }}
                  onMouseEnter={e => { if (selected !== v.id) e.currentTarget.style.background = 'rgba(255,255,255,0.02)'; }}
                  onMouseLeave={e => { if (selected !== v.id) e.currentTarget.style.background = 'transparent'; }}
                >
                  <td style={{ padding: '12px 16px', fontSize: 12, color: 'var(--text)', fontWeight: selected === v.id ? 500 : 400 }}>{v.name}</td>
                  <td style={{ padding: '12px 16px', fontSize: 11, color: 'var(--text-3)' }}>{v.location}</td>
                  <td style={{ padding: '12px 16px', fontSize: 11, color: 'var(--text-2)', fontFamily: 'var(--font-mono)' }}>{v.distance}</td>
                  <td style={{ padding: '12px 16px', fontSize: 11, color: v.moisture > 15 ? 'var(--rose)' : 'var(--jade)', fontFamily: 'var(--font-mono)' }}>{v.moisture}%</td>
                  <td style={{ padding: '12px 16px', fontSize: 11, color: 'var(--text-2)', fontFamily: 'var(--font-mono)' }}>{v.stock}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{
                      fontSize: 9, padding: '3px 8px', borderRadius: 4,
                      background: `${STATUS_COLOR[v.status]}22`,
                      color: STATUS_COLOR[v.status],
                      fontFamily: 'var(--font-mono)', letterSpacing: '0.06em',
                    }}>{v.status.toUpperCase()}</span>
                  </td>
                  <td style={{ padding: '12px 16px', fontSize: 11, color: 'var(--text-2)', fontFamily: 'var(--font-mono)' }}>{v.eta}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Vendor detail */}
        {vendor && (
          <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: 20, display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em' }}>VENDOR DETAIL</div>
            <div>
              <div style={{ fontSize: 16, fontWeight: 500, color: 'var(--text)', marginBottom: 2 }}>{vendor.name}</div>
              <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{vendor.location} · {vendor.distance}</div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                { label: 'Status', val: vendor.status, color: STATUS_COLOR[vendor.status] },
                { label: 'ETA', val: vendor.eta, color: 'var(--text-2)' },
                { label: 'Batch Qty', val: `${vendor.qty} T`, color: 'var(--text-2)' },
                { label: 'Moisture', val: `${vendor.moisture}%`, color: vendor.moisture > 15 ? 'var(--rose)' : 'var(--jade)' },
                { label: 'Stock', val: `${vendor.stock} T`, color: 'var(--text-2)' },
              ].map(row => (
                <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                  <span style={{ fontSize: 11, color: 'var(--text-3)' }}>{row.label}</span>
                  <span style={{ fontSize: 11, color: row.color, fontFamily: 'var(--font-mono)', fontWeight: 500 }}>{row.val}</span>
                </div>
              ))}
            </div>
            {/* Reliability bar */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>RELIABILITY SCORE</span>
                <span style={{ fontSize: 10, color: vendor.reliability > 85 ? 'var(--jade)' : 'var(--amber)', fontFamily: 'var(--font-mono)' }}>{vendor.reliability}%</span>
              </div>
              <div style={{ height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 99 }}>
                <div style={{ height: '100%', width: `${vendor.reliability}%`, background: vendor.reliability > 85 ? 'var(--jade)' : 'var(--amber)', borderRadius: 99 }} />
              </div>
            </div>
            {/* Map placeholder */}
            <div style={{
              height: 100, borderRadius: 9, background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 4,
            }}>
              <span style={{ fontSize: 20, opacity: 0.3 }}>⬡</span>
              <span style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>GPS ROUTE MAP</span>
              <span style={{ fontSize: 9, color: 'var(--text-3)' }}>{vendor.distance} from plant</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
