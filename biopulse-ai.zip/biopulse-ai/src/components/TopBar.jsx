import React, { useState, useEffect } from 'react';

export default function TopBar({ user, onLogout, alerts, data }) {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const fmt = (n, d = 1) => Number(n).toFixed(d);

  return (
    <header style={{
      height: 56, background: 'var(--ink-2)', borderBottom: '1px solid var(--border)',
      display: 'flex', alignItems: 'center', padding: '0 24px',
      gap: 20, flexShrink: 0,
    }}>
      {/* Live stats strip */}
      <div style={{ display: 'flex', gap: 20, flex: 1 }}>
        {[
          { label: 'BOILER', val: `${fmt(data.boilerTemp)}°C`, color: data.boilerTemp > 340 ? 'var(--rose)' : 'var(--amber)' },
          { label: 'TURBINE', val: `${fmt(data.turbineOutput, 0)} kW`, color: 'var(--teal)' },
          { label: 'STEAM', val: `${fmt(data.steamPressure)} bar`, color: 'var(--sky)' },
          { label: 'ETHANOL', val: `${fmt(data.ethanolProduction)} L/h`, color: 'var(--jade)' },
        ].map(s => (
          <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em' }}>{s.label}</span>
            <span style={{ fontSize: 12, color: s.color, fontFamily: 'var(--font-mono)', fontWeight: 500 }}>{s.val}</span>
          </div>
        ))}
      </div>

      {/* Alerts badge */}
      {alerts.length > 0 && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 6,
          padding: '4px 10px', borderRadius: 6,
          background: 'var(--rose-dim)', border: '1px solid rgba(232,91,75,0.25)',
          fontSize: 11, color: 'var(--rose)',
        }}>
          <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--rose)', animation: 'blink 1s infinite' }} />
          {alerts.length} alert{alerts.length > 1 ? 's' : ''}
        </div>
      )}

      {/* Clock */}
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-3)', whiteSpace: 'nowrap' }}>
        {time.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
      </div>

      {/* User */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingLeft: 16, borderLeft: '1px solid var(--border)' }}>
        <div style={{
          width: 28, height: 28, borderRadius: '50%',
          background: 'linear-gradient(135deg, var(--amber) 0%, #c47e2a 100%)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 11, fontWeight: 700, color: '#0d1117',
        }}>
          {(user?.role || 'U').charAt(0)}
        </div>
        <div>
          <div style={{ fontSize: 11, color: 'var(--text)', fontWeight: 500 }}>{user?.role || 'Engineer'}</div>
          <div style={{ fontSize: 10, color: 'var(--text-3)' }}>{user?.email}</div>
        </div>
        <button onClick={onLogout} style={{
          marginLeft: 8, padding: '4px 10px', borderRadius: 6,
          border: '1px solid var(--border)', color: 'var(--text-3)',
          fontSize: 11, cursor: 'pointer', transition: 'var(--transition)',
          background: 'transparent',
        }}
          onMouseEnter={e => { e.currentTarget.style.color = 'var(--rose)'; e.currentTarget.style.borderColor = 'rgba(232,91,75,0.3)'; }}
          onMouseLeave={e => { e.currentTarget.style.color = 'var(--text-3)'; e.currentTarget.style.borderColor = 'var(--border)'; }}
        >
          Sign out
        </button>
      </div>
    </header>
  );
}
