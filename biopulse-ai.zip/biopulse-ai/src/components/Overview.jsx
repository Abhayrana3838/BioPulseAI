import React from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const fmt = (n, d = 1) => Number(n).toFixed(d);

function MetricCard({ label, value, unit, sub, color, delta }) {
  return (
    <div style={{
      background: 'var(--ink-2)', borderRadius: 14,
      border: `1px solid var(--border)`,
      padding: '20px 22px', position: 'relative', overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 2,
        background: color, opacity: 0.7, borderRadius: '14px 14px 0 0',
      }} />
      <div style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', marginBottom: 8 }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 5, marginBottom: 4 }}>
        <span style={{ fontSize: 28, fontWeight: 300, color: 'var(--text)', letterSpacing: '-0.03em', fontFamily: 'var(--font-display)' }}>{value}</span>
        <span style={{ fontSize: 12, color: 'var(--text-3)' }}>{unit}</span>
      </div>
      <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{sub}</div>
      {delta !== undefined && (
        <div style={{
          position: 'absolute', top: 16, right: 18,
          fontSize: 11, color: delta >= 0 ? 'var(--jade)' : 'var(--rose)',
          fontFamily: 'var(--font-mono)',
        }}>{delta >= 0 ? '▲' : '▼'} {Math.abs(delta)}%</div>
      )}
    </div>
  );
}

function Gauge({ label, value, max, color }) {
  const pct = Math.min(value / max, 1);
  const r = 34, cx = 44, cy = 44;
  const startAngle = Math.PI * 0.75;
  const endAngle = Math.PI * 2.25;
  const angle = startAngle + pct * (endAngle - startAngle);
  const arc = (a) => [cx + r * Math.cos(a - Math.PI / 2), cy + r * Math.sin(a - Math.PI / 2)];
  const bgPath = `M ${arc(startAngle).join(' ')} A ${r} ${r} 0 1 1 ${arc(endAngle).join(' ')}`;
  const fgPath = pct > 0 ? `M ${arc(startAngle).join(' ')} A ${r} ${r} 0 ${pct > 0.5 ? 1 : 0} 1 ${arc(angle).join(' ')}` : null;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
      <svg width={88} height={70} viewBox="0 0 88 70">
        <path d={bgPath} stroke="rgba(255,255,255,0.07)" strokeWidth={7} fill="none" strokeLinecap="round" />
        {fgPath && <path d={fgPath} stroke={color} strokeWidth={7} fill="none" strokeLinecap="round" style={{ filter: `drop-shadow(0 0 4px ${color})` }} />}
        <text x={44} y={50} textAnchor="middle" fill="var(--text)" fontSize={13} fontFamily="var(--font-mono)" fontWeight={500}>
          {value % 1 === 0 ? value : value.toFixed(1)}
        </text>
      </svg>
      <span style={{ fontSize: 10, color: 'var(--text-3)', textAlign: 'center', maxWidth: 70 }}>{label}</span>
    </div>
  );
}

function AlertBanner({ alerts }) {
  if (!alerts.length) return null;
  return (
    <div style={{
      background: 'rgba(232,91,75,0.08)', border: '1px solid rgba(232,91,75,0.2)',
      borderRadius: 12, padding: '14px 18px', marginBottom: 20,
    }}>
      <div style={{ fontSize: 11, color: 'var(--rose)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 8 }}>
        ⚠ ACTIVE ALERTS ({alerts.length})
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {alerts.map(a => (
          <div key={a.id} style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <span style={{
              fontSize: 9, padding: '2px 7px', borderRadius: 4,
              background: a.level === 'critical' ? 'rgba(232,91,75,0.25)' : 'rgba(232,162,75,0.2)',
              color: a.level === 'critical' ? 'var(--rose)' : 'var(--amber)',
              fontFamily: 'var(--font-mono)', letterSpacing: '0.06em', textTransform: 'uppercase',
            }}>{a.level}</span>
            <span style={{ fontSize: 12, color: 'var(--text-2)' }}>{a.msg}</span>
            <span style={{ fontSize: 11, color: 'var(--text-3)', marginLeft: 'auto' }}>{a.system}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Overview({ data, history, alerts }) {
  const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload?.length) return null;
    return (
      <div style={{ background: 'var(--ink-3)', border: '1px solid var(--border)', borderRadius: 8, padding: '8px 12px' }}>
        {payload.map(p => (
          <div key={p.dataKey} style={{ fontSize: 11, color: p.color, fontFamily: 'var(--font-mono)' }}>
            {p.name}: {Number(p.value).toFixed(1)}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div>
      <div style={{ marginBottom: 22, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 400, fontFamily: 'var(--font-display)', color: 'var(--text)', marginBottom: 2 }}>Live Overview</h1>
          <div style={{ fontSize: 12, color: 'var(--text-3)' }}>Real-time plant telemetry — updated every 1.5s</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--jade)', animation: 'blink 1.5s infinite', display: 'inline-block' }} />
          <span style={{ fontSize: 11, color: 'var(--jade)', fontFamily: 'var(--font-mono)', letterSpacing: '0.06em' }}>LIVE</span>
        </div>
      </div>

      <AlertBanner alerts={alerts} />

      {/* Metric cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 20 }}>
        <MetricCard label="BOILER TEMP" value={fmt(data.boilerTemp)} unit="°C" sub="Rated: 280–350°C" color="var(--amber)" delta={1.2} />
        <MetricCard label="TURBINE OUTPUT" value={fmt(data.turbineOutput, 0)} unit="kW" sub="Capacity: 3200 kW" color="var(--teal)" delta={-0.4} />
        <MetricCard label="STEAM PRESSURE" value={fmt(data.steamPressure)} unit="bar" sub="Design: 20 bar" color="var(--sky)" delta={0.8} />
        <MetricCard label="BIOMASS FLOW" value={fmt(data.biomassFlow)} unit="T/hr" sub="Target: 4.0–5.0 T/hr" color="var(--jade)" delta={2.1} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginBottom: 20 }}>
        {/* Main chart */}
        <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: '20px 20px 12px' }}>
          <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 16 }}>BOILER TEMP & TURBINE OUTPUT — LIVE STREAM</div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={history} margin={{ top: 4, right: 4, bottom: 0, left: -10 }}>
              <defs>
                <linearGradient id="gt1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--amber)" stopOpacity={0.25} />
                  <stop offset="100%" stopColor="var(--amber)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gt2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--teal)" stopOpacity={0.2} />
                  <stop offset="100%" stopColor="var(--teal)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="t" hide />
              <YAxis yAxisId="left" domain={[280, 370]} hide />
              <YAxis yAxisId="right" orientation="right" domain={[2400, 3200]} hide />
              <Tooltip content={<CustomTooltip />} />
              <Area yAxisId="left" type="monotone" dataKey="boilerTemp" stroke="var(--amber)" strokeWidth={1.5} fill="url(#gt1)" name="Boiler Temp" dot={false} />
              <Area yAxisId="right" type="monotone" dataKey="turbineOutput" stroke="var(--teal)" strokeWidth={1.5} fill="url(#gt2)" name="Turbine kW" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
          <div style={{ display: 'flex', gap: 16, marginTop: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 10, color: 'var(--text-3)' }}>
              <span style={{ width: 16, height: 2, background: 'var(--amber)', display: 'inline-block' }} /> Boiler Temp (°C)
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 10, color: 'var(--text-3)' }}>
              <span style={{ width: 16, height: 2, background: 'var(--teal)', display: 'inline-block' }} /> Turbine Output (kW)
            </div>
          </div>
        </div>

        {/* System status */}
        <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: '20px' }}>
          <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 16 }}>SYSTEM STATUS</div>
          {[
            { label: 'Boiler Unit', pct: Math.round((data.boilerTemp - 280) / 70 * 100), color: 'var(--amber)' },
            { label: 'Turbine Generator', pct: Math.round(data.turbineOutput / 3200 * 100), color: 'var(--teal)' },
            { label: 'ESP Filter', pct: Math.round(data.espEfficiency), color: 'var(--jade)' },
            { label: 'Conveyor Belt', pct: Math.round(data.conveyorSpeed / 2.5 * 100), color: 'var(--sky)' },
            { label: 'Ash Collection', pct: Math.round(data.ashCollection), color: 'var(--amber)' },
            { label: 'CO₂ Recovery', pct: Math.round(data.co2Recovery), color: 'var(--teal)' },
          ].map(s => (
            <div key={s.label} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 11, color: 'var(--text-2)' }}>{s.label}</span>
                <span style={{ fontSize: 10, color: s.color, fontFamily: 'var(--font-mono)' }}>{s.pct}%</span>
              </div>
              <div style={{ height: 3, background: 'rgba(255,255,255,0.06)', borderRadius: 99, overflow: 'hidden' }}>
                <div style={{
                  height: '100%', width: `${s.pct}%`, background: s.color,
                  borderRadius: 99, transition: 'width 0.8s ease',
                  boxShadow: `0 0 6px ${s.color}`,
                }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Gauges row */}
      <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: '20px' }}>
        <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 16 }}>PROCESS GAUGES</div>
        <div style={{ display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap', gap: 12 }}>
          <Gauge label="CO₂ Recovery" value={Math.round(data.co2Recovery)} max={100} color="var(--teal)" />
          <Gauge label="ESP Efficiency" value={Math.round(data.espEfficiency)} max={100} color="var(--jade)" />
          <Gauge label="Ethanol L/hr" value={Math.round(data.ethanolProduction)} max={165} color="var(--amber)" />
          <Gauge label="DDGS T/hr" value={Number(data.ddgsOutput.toFixed(1))} max={50} color="var(--sky)" />
          <Gauge label="Ash Coll. %" value={Math.round(data.ashCollection)} max={100} color="var(--amber)" />
          <Gauge label="Fuel T/hr" value={Number(data.fuelConsumption.toFixed(1))} max={15} color="var(--rose)" />
        </div>
      </div>
    </div>
  );
}
