import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const co2Data = months.map((m, i) => ({
  month: m,
  reduction: 420 + Math.sin(i * 0.6) * 60 + i * 12,
  baseline: 820,
}));

const firesData = months.map((m, i) => ({
  month: m,
  fires: Math.max(0, Math.round(45 - i * 1.8 + Math.sin(i) * 8)),
}));

export default function CarbonAnalytics({ data, history }) {
  const annualCO2 = 4800; // tonnes
  const stubblePrevented = 860;
  const credits = Math.round(annualCO2 * 18.5);
  const renewableGen = Math.round(data.turbineOutput * 8760 / 1000000 * 12);

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div style={{ background: 'var(--ink-3)', border: '1px solid var(--border)', borderRadius: 8, padding: '8px 12px' }}>
        <div style={{ fontSize: 10, color: 'var(--text-3)', marginBottom: 4 }}>{label}</div>
        {payload.map(p => (
          <div key={p.dataKey} style={{ fontSize: 11, color: p.color, fontFamily: 'var(--font-mono)' }}>
            {p.name}: {Number(p.value).toFixed(0)}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div>
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 22, fontWeight: 400, fontFamily: 'var(--font-display)', color: 'var(--text)', marginBottom: 2 }}>Carbon Analytics</h1>
        <div style={{ fontSize: 12, color: 'var(--text-3)' }}>ESG performance, sustainability metrics, and carbon credit tracking</div>
      </div>

      {/* ESG metric cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 20 }}>
        {[
          { label: 'CO₂ REDUCTION', val: `${(annualCO2 / 1000).toFixed(1)}K`, unit: 'T/year', sub: 'vs coal baseline', color: 'var(--teal)', icon: '↓' },
          { label: 'STUBBLE FIRES', val: stubblePrevented.toString(), unit: 'prevented', sub: 'Parali utilization', color: 'var(--jade)', icon: '⊗' },
          { label: 'CARBON CREDITS', val: `₹${(credits / 100000).toFixed(1)}L`, unit: 'est.', sub: '@₹18.5/T CO₂', color: 'var(--amber)', icon: '◈' },
          { label: 'RENEWABLE GEN', val: `${renewableGen}`, unit: 'MWh/yr', sub: 'Biomass power', color: 'var(--sky)', icon: '⚡' },
        ].map(c => (
          <div key={c.label} style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: '18px 20px', position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: c.color, borderRadius: '14px 14px 0 0' }} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <div style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em' }}>{c.label}</div>
              <span style={{ fontSize: 14, color: c.color, opacity: 0.8 }}>{c.icon}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 3 }}>
              <span style={{ fontSize: 24, fontWeight: 300, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>{c.val}</span>
              <span style={{ fontSize: 11, color: 'var(--text-3)' }}>{c.unit}</span>
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{c.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        {/* CO2 Reduction chart */}
        <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: '20px 20px 12px' }}>
          <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 16 }}>CO₂ REDUCTION — TONNES/MONTH</div>
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={co2Data} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="gco2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--teal)" stopOpacity={0.25} />
                  <stop offset="100%" stopColor="var(--teal)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" tick={{ fill: 'var(--text-3)', fontSize: 9, fontFamily: 'var(--font-mono)' }} axisLine={false} tickLine={false} />
              <YAxis hide domain={[300, 700]} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="reduction" stroke="var(--teal)" strokeWidth={1.5} fill="url(#gco2)" name="CO₂ Reduction (T)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Stubble fires bar chart */}
        <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: '20px 20px 12px' }}>
          <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 16 }}>STUBBLE FIRES PREVENTED — MONTHLY</div>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={firesData} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
              <XAxis dataKey="month" tick={{ fill: 'var(--text-3)', fontSize: 9, fontFamily: 'var(--font-mono)' }} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="fires" fill="var(--jade)" name="Fires Prevented" radius={[3, 3, 0, 0]} opacity={0.8} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ESG compliance */}
      <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: 20 }}>
        <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 16 }}>ESG COMPLIANCE SCORECARD</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {[
            { label: 'Air Quality (AQI)', score: 92, status: 'Compliant', color: 'var(--jade)' },
            { label: 'Water Usage', score: 88, status: 'Compliant', color: 'var(--jade)' },
            { label: 'Noise Level', score: 96, status: 'Excellent', color: 'var(--teal)' },
            { label: 'Ash Disposal', score: 84, status: 'Compliant', color: 'var(--amber)' },
            { label: 'Carbon Reporting', score: 100, status: 'Certified', color: 'var(--jade)' },
            { label: 'Renewables Mix', score: 78, status: 'Improving', color: 'var(--amber)' },
          ].map(s => (
            <div key={s.label} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 12, color: 'var(--text-2)' }}>{s.label}</span>
                <span style={{ fontSize: 10, color: s.color, fontFamily: 'var(--font-mono)' }}>{s.score}</span>
              </div>
              <div style={{ height: 3, background: 'rgba(255,255,255,0.06)', borderRadius: 99 }}>
                <div style={{ height: '100%', width: `${s.score}%`, background: s.color, borderRadius: 99 }} />
              </div>
              <span style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>{s.status.toUpperCase()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
