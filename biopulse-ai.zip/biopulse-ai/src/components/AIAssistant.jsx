import React, { useState, useRef, useEffect } from 'react';

const QUICK = [
  'Why is boiler temperature fluctuating?',
  'What is the current ethanol yield efficiency?',
  'Analyze conveyor maintenance schedule',
  'CO₂ recovery optimization tips',
  'Explain DDGS output drop',
];

export default function AIAssistant({ data }) {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: `Industrial AI Assistant online. I have full access to real-time plant data:\n\n• Boiler: ${data.boilerTemp.toFixed(1)}°C @ ${data.steamPressure.toFixed(1)} bar\n• Turbine: ${data.turbineOutput.toFixed(0)} kW output\n• Ethanol: ${data.ethanolProduction.toFixed(0)} L/hr\n• CO₂ recovery: ${data.co2Recovery.toFixed(1)}%\n\nAsk me anything about plant operations, maintenance, process optimization, or biomass logistics.`,
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const send = async (text) => {
    const userText = text || input.trim();
    if (!userText) return;
    setInput('');
    const newMessages = [...messages, { role: 'user', content: userText }];
    setMessages(newMessages);
    setLoading(true);

    const systemPrompt = `You are an expert Industrial AI Assistant for a biomass co-generation plant in Haryana, India. 
You have real-time access to these sensor readings:
- Boiler Temperature: ${data.boilerTemp.toFixed(1)}°C (optimal: 280-340°C)
- Steam Pressure: ${data.steamPressure.toFixed(1)} bar (design: 20 bar)
- Turbine Output: ${data.turbineOutput.toFixed(0)} kW (capacity: 3200 kW)
- Biomass Flow: ${data.biomassFlow.toFixed(1)} T/hr
- CO₂ Recovery: ${data.co2Recovery.toFixed(1)}%
- Ethanol Production: ${data.ethanolProduction.toFixed(0)} L/hr
- DDGS Output: ${data.ddgsOutput.toFixed(1)} T/hr
- Ash Collection: ${data.ashCollection.toFixed(1)}%
- ESP Efficiency: ${data.espEfficiency.toFixed(1)}%
- Conveyor Speed: ${data.conveyorSpeed.toFixed(1)} m/s
- Fuel Consumption: ${data.fuelConsumption.toFixed(1)} T/hr

You have deep expertise in: biomass combustion, steam cycles, distillation, ESG compliance, predictive maintenance, DDGS production, parali (paddy straw) handling.

Respond concisely, professionally, and with actionable insights. When data shows anomalies, highlight them. Format with clear sections if needed. Keep responses focused and technically precise.`;

    try {
      const resp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: systemPrompt,
          messages: newMessages.map(m => ({ role: m.role, content: m.content })),
        })
      });
      const d = await resp.json();
      const reply = d.content?.[0]?.text || 'Unable to get response.';
      setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Connection error. Please check API access and retry.' }]);
    }
    setLoading(false);
  };

  return (
    <div>
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 22, fontWeight: 400, fontFamily: 'var(--font-display)', color: 'var(--text)', marginBottom: 2 }}>Industrial AI Assistant</h1>
        <div style={{ fontSize: 12, color: 'var(--text-3)' }}>Plant-aware GPT — trained on live sensor data, SOPs, and maintenance knowledge</div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 220px', gap: 16, height: 'calc(100vh - 220px)', minHeight: 500 }}>
        {/* Chat panel */}
        <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {/* Header */}
          <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: 'linear-gradient(135deg, var(--amber), #c47e2a)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, color: '#0d1117', fontWeight: 700 }}>AI</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)' }}>BioPulse Industrial GPT</div>
              <div style={{ fontSize: 10, color: 'var(--jade)', display: 'flex', alignItems: 'center', gap: 5 }}>
                <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'var(--jade)', animation: 'blink 2s infinite' }} />
                CONNECTED TO LIVE PLANT DATA
              </div>
            </div>
          </div>

          {/* Messages */}
          <div style={{ flex: 1, overflow: 'auto', padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 14 }}>
            {messages.map((msg, i) => (
              <div key={i} style={{ display: 'flex', gap: 10, justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
                {msg.role === 'assistant' && (
                  <div style={{ width: 24, height: 24, borderRadius: 6, background: 'linear-gradient(135deg, var(--amber), #c47e2a)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, color: '#0d1117', fontWeight: 700, flexShrink: 0, marginTop: 2 }}>B</div>
                )}
                <div style={{
                  maxWidth: '78%', padding: '10px 14px', borderRadius: msg.role === 'user' ? '12px 12px 4px 12px' : '12px 12px 12px 4px',
                  background: msg.role === 'user' ? 'rgba(232,162,75,0.12)' : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${msg.role === 'user' ? 'rgba(232,162,75,0.2)' : 'var(--border)'}`,
                  fontSize: 13, color: 'var(--text)', lineHeight: 1.65,
                  whiteSpace: 'pre-wrap',
                }}>
                  {msg.content}
                </div>
              </div>
            ))}
            {loading && (
              <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                <div style={{ width: 24, height: 24, borderRadius: 6, background: 'linear-gradient(135deg, var(--amber), #c47e2a)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, color: '#0d1117', fontWeight: 700 }}>B</div>
                <div style={{ display: 'flex', gap: 5, padding: '10px 14px', background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)', borderRadius: '12px 12px 12px 4px' }}>
                  {[0, 1, 2].map(d => (
                    <span key={d} style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--amber)', display: 'inline-block', animation: `blink 1s ${d * 0.2}s infinite` }} />
                  ))}
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div style={{ padding: '12px 16px', borderTop: '1px solid var(--border)', display: 'flex', gap: 10 }}>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
              placeholder="Ask about plant operations, failures, optimization…"
              disabled={loading}
              style={{
                flex: 1, background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)',
                borderRadius: 9, padding: '10px 14px', color: 'var(--text)',
                fontSize: 13, outline: 'none', transition: 'border-color 0.2s',
              }}
              onFocus={e => e.target.style.borderColor = 'rgba(232,162,75,0.4)'}
              onBlur={e => e.target.style.borderColor = 'var(--border)'}
            />
            <button onClick={() => send()} disabled={loading || !input.trim()}
              style={{
                padding: '10px 16px', borderRadius: 9,
                background: (!input.trim() || loading) ? 'rgba(232,162,75,0.2)' : 'var(--amber)',
                color: '#0d1117', fontWeight: 600, fontSize: 13,
                cursor: (!input.trim() || loading) ? 'not-allowed' : 'pointer',
                transition: 'var(--transition)', whiteSpace: 'nowrap',
              }}>
              Send
            </button>
          </div>
        </div>

        {/* Quick prompts sidebar */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: 18 }}>
            <div style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 12 }}>QUICK PROMPTS</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {QUICK.map((q, i) => (
                <button key={i} onClick={() => send(q)} disabled={loading}
                  style={{
                    padding: '9px 12px', borderRadius: 8, textAlign: 'left',
                    border: '1px solid var(--border)', background: 'transparent',
                    color: 'var(--text-2)', fontSize: 11, cursor: 'pointer',
                    transition: 'var(--transition)', lineHeight: 1.4,
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = 'var(--amber-dim)'; e.currentTarget.style.borderColor = 'rgba(232,162,75,0.25)'; e.currentTarget.style.color = 'var(--amber)'; }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--text-2)'; }}
                >{q}</button>
              ))}
            </div>
          </div>

          {/* Live context card */}
          <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: 18 }}>
            <div style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 12 }}>LIVE CONTEXT</div>
            {[
              { k: 'Boiler', v: `${data.boilerTemp.toFixed(1)}°C` },
              { k: 'Turbine', v: `${data.turbineOutput.toFixed(0)} kW` },
              { k: 'Ethanol', v: `${data.ethanolProduction.toFixed(0)} L/h` },
              { k: 'CO₂ Rec.', v: `${data.co2Recovery.toFixed(1)}%` },
            ].map(item => (
              <div key={item.k} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', borderBottom: '1px solid var(--border)' }}>
                <span style={{ fontSize: 10, color: 'var(--text-3)' }}>{item.k}</span>
                <span style={{ fontSize: 10, color: 'var(--amber)', fontFamily: 'var(--font-mono)' }}>{item.v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
