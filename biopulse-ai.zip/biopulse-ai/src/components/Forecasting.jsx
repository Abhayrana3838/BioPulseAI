import React from 'react';
import { ComposedChart, Line, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, AreaChart, Area } from 'recharts';

const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const today = new Date().getDay();

function genForecast(data) {
  return days.map((d, i) => ({
    day: d,
    ethanol: Math.round(data.ethanolProduction * (0.92 + Math.random() * 0.16) * 24),
    power: Math.round(data.turbineOutput * (0.90 + Math.random() * 0.15)),
    biomass: +(data.biomassFlow * (0.88 + Math.random() * 0.2) * 24).toFixed(1),
    maintenance: i === 3 ? 1 : 0,
    confidence: Math.round(90 - i * 3),
  }));
}

export default function Forecasting({ data }) {
  const forecast = React.useMemo(() => genForecast(data), []);

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div style={{ background: 'var(--ink-3)', border: '1px solid var(--border)', borderRadius: 8, padding: '10px 14px' }}>
        <div style={{ fontSize: 10, color: 'var(--text-3)', marginBottom: 6, fontFamily: 'var(--font-mono)' }}>{label}</div>
        {payload.map(p => (
          <div key={p.dataKey} style={{ fontSize: 11, color: p.color || 'var(--text)', fontFamily: 'var(--font-mono)', marginBottom: 2 }}>
            {p.name}: {p.value}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div>
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 22, fontWeight: 400, fontFamily: 'var(--font-display)', color: 'var(--text)', marginBottom: 2 }}>Forecasting</h1>
        <div style={{ fontSize: 12, color: 'var(--text-3)' }}>7-day AI production outlook — ethanol, power, biomass demand & maintenance cycles</div>
      </div>

      {/* Summary row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 20 }}>
        {[
          { label: '7-DAY ETHANOL', val: forecast.reduce((a, d) => a + d.ethanol, 0).toLocaleString(), unit: 'L', color: 'var(--jade)' },
          { label: 'AVG POWER', val: Math.round(forecast.reduce((a, d) => a + d.power, 0) / 7).toLocaleString(), unit: 'kW', color: 'var(--teal)' },
          { label: 'BIOMASS REQ.', val: forecast.reduce((a, d) => a + d.biomass, 0).toFixed(0), unit: 'T', color: 'var(--amber)' },
          { label: 'MAINT. WINDOWS', val: forecast.filter(d => d.maintenance).length.toString(), unit: 'planned', color: 'var(--sky)' },
        ].map(c => (
          <div key={c.label} style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: '18px 20px', position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: c.color, borderRadius: '14px 14px 0 0' }} />
            <div style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', marginBottom: 6 }}>{c.label}</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
              <span style={{ fontSize: 24, fontWeight: 300, color: 'var(--text)', fontFamily: 'var(--font-display)' }}>{c.val}</span>
              <span style={{ fontSize: 11, color: 'var(--text-3)' }}>{c.unit}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Ethanol + Power chart */}
      <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: '20px 20px 12px', marginBottom: 16 }}>
        <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 16 }}>
          7-DAY ETHANOL PRODUCTION & TURBINE OUTPUT FORECAST
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <ComposedChart data={forecast} margin={{ top: 4, right: 8, bottom: 0, left: -10 }}>
            <defs>
              <linearGradient id="getoh" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--jade)" stopOpacity={0.3} />
                <stop offset="100%" stopColor="var(--jade)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="day" tick={{ fill: 'var(--text-3)', fontSize: 10, fontFamily: 'var(--font-mono)' }} axisLine={false} tickLine={false} />
            <YAxis yAxisId="left" hide />
            <YAxis yAxisId="right" orientation="right" hide />
            <Tooltip content={<CustomTooltip />} />
            <Bar yAxisId="right" dataKey="power" fill="rgba(78,205,196,0.2)" stroke="var(--teal)" strokeWidth={1} name="Power (kW)" radius={[4, 4, 0, 0]} />
            <Area yAxisId="left" type="monotone" dataKey="ethanol" stroke="var(--jade)" strokeWidth={2} fill="url(#getoh)" name="Ethanol (L)" dot={{ fill: 'var(--jade)', r: 3 }} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Day-by-day table */}
      <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, overflow: 'hidden' }}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em' }}>
          DAILY FORECAST BREAKDOWN
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'rgba(255,255,255,0.02)' }}>
              {['Day', 'Ethanol (L)', 'Power (kW)', 'Biomass (T)', 'Maintenance', 'Confidence'].map(h => (
                <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', fontWeight: 400 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {forecast.map((row, i) => (
              <tr key={row.day} style={{ borderTop: '1px solid var(--border)', background: row.maintenance ? 'rgba(232,162,75,0.04)' : 'transparent' }}>
                <td style={{ padding: '12px 16px', fontSize: 12, color: i === 0 ? 'var(--amber)' : 'var(--text)', fontWeight: i === 0 ? 500 : 400 }}>
                  {row.day} {i === 0 ? '(Today)' : ''}
                </td>
                <td style={{ padding: '12px 16px', fontSize: 11, color: 'var(--jade)', fontFamily: 'var(--font-mono)' }}>{row.ethanol.toLocaleString()}</td>
                <td style={{ padding: '12px 16px', fontSize: 11, color: 'var(--teal)', fontFamily: 'var(--font-mono)' }}>{row.power.toLocaleString()}</td>
                <td style={{ padding: '12px 16px', fontSize: 11, color: 'var(--text-2)', fontFamily: 'var(--font-mono)' }}>{row.biomass}</td>
                <td style={{ padding: '12px 16px' }}>
                  {row.maintenance ? (
                    <span style={{ fontSize: 9, padding: '2px 8px', borderRadius: 4, background: 'var(--amber-dim)', color: 'var(--amber)', fontFamily: 'var(--font-mono)' }}>SCHEDULED</span>
                  ) : (
                    <span style={{ fontSize: 9, padding: '2px 8px', borderRadius: 4, background: 'var(--jade-dim)', color: 'var(--jade)', fontFamily: 'var(--font-mono)' }}>NOMINAL</span>
                  )}
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ flex: 1, height: 3, background: 'rgba(255,255,255,0.06)', borderRadius: 99 }}>
                      <div style={{ height: '100%', width: `${row.confidence}%`, background: row.confidence > 80 ? 'var(--jade)' : 'var(--amber)', borderRadius: 99 }} />
                    </div>
                    <span style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', width: 30 }}>{row.confidence}%</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
