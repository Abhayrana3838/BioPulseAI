import React from 'react';

const NAV = [
  { id: 'overview', icon: '◈', label: 'Live Overview', sub: 'Plant metrics' },
  { id: 'twin', icon: '⬡', label: 'Digital Twin', sub: 'Plant simulation' },
  { id: 'maintenance', icon: '⚙', label: 'Predictive AI', sub: 'ML diagnostics' },
  { id: 'assistant', icon: '◎', label: 'AI Assistant', sub: 'Industrial GPT' },
  { id: 'supply', icon: '⬢', label: 'Supply Chain', sub: 'Biomass logistics' },
  { id: 'carbon', icon: '◉', label: 'Carbon Analytics', sub: 'ESG dashboard' },
  { id: 'forecast', icon: '◫', label: 'Forecasting', sub: '7-day outlook' },
];

export default function Sidebar({ active, setActive, alerts }) {
  return (
    <nav style={{
      width: 220, background: 'var(--ink-2)', borderRight: '1px solid var(--border)',
      display: 'flex', flexDirection: 'column', padding: '0 0 16px',
      flexShrink: 0,
    }}>
      {/* Logo */}
      <div style={{
        padding: '20px 20px 18px',
        borderBottom: '1px solid var(--border)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 30, height: 30, borderRadius: 8,
            background: 'linear-gradient(135deg, var(--amber), #c47e2a)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 700, fontSize: 14, color: '#0d1117',
            boxShadow: '0 2px 10px var(--amber-glow)',
          }}>B</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', letterSpacing: '-0.02em' }}>BioPulse</div>
            <div style={{ fontSize: 9, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em' }}>AI PLATFORM</div>
          </div>
        </div>
      </div>

      {/* Nav items */}
      <div style={{ flex: 1, padding: '12px 12px 0', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV.map(item => {
          const isActive = active === item.id;
          const hasAlert = item.id === 'overview' && alerts.length > 0;
          return (
            <button key={item.id} onClick={() => setActive(item.id)}
              style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '9px 12px', borderRadius: 9, cursor: 'pointer',
                background: isActive ? 'rgba(232,162,75,0.1)' : 'transparent',
                border: `1px solid ${isActive ? 'rgba(232,162,75,0.2)' : 'transparent'}`,
                textAlign: 'left', transition: 'var(--transition)',
                position: 'relative',
              }}
              onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; }}
              onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = 'transparent'; }}
            >
              <span style={{
                fontSize: 14, color: isActive ? 'var(--amber)' : 'var(--text-3)',
                transition: 'var(--transition)', width: 18, textAlign: 'center',
              }}>{item.icon}</span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: isActive ? 500 : 400, color: isActive ? 'var(--amber)' : 'var(--text-2)', transition: 'var(--transition)' }}>
                  {item.label}
                </div>
                <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 1 }}>{item.sub}</div>
              </div>
              {hasAlert && (
                <span style={{
                  width: 6, height: 6, borderRadius: '50%', background: 'var(--rose)',
                  animation: 'blink 1.5s infinite',
                }} />
              )}
            </button>
          );
        })}
      </div>

      {/* Footer */}
      <div style={{ padding: '12px 20px 0', borderTop: '1px solid var(--border)', marginTop: 12 }}>
        <div style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', lineHeight: 1.7 }}>
          <div>UNIT 1 — HARYANA</div>
          <div style={{ color: 'var(--jade)' }}>● ONLINE</div>
          <div style={{ marginTop: 4 }}>v2.4.1-stable</div>
        </div>
      </div>
    </nav>
  );
}
