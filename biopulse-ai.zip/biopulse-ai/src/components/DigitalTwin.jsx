import React, { useEffect, useRef } from 'react';

function StatusDot({ x, y, active, label }) {
  return (
    <g>
      <circle cx={x} cy={y} r={5} fill={active ? 'var(--jade)' : 'var(--rose)'} style={{ filter: `drop-shadow(0 0 4px ${active ? 'var(--jade)' : 'var(--rose)'})` }} />
      <circle cx={x} cy={y} r={8} fill="none" stroke={active ? 'var(--jade)' : 'var(--rose)'} strokeWidth={1} opacity={0.4} style={{ animation: 'pulse-ring 2s infinite' }} />
      <text x={x + 10} y={y + 4} fill="var(--text-2)" fontSize={9} fontFamily="var(--font-mono)">{label}</text>
    </g>
  );
}

export default function DigitalTwin({ data }) {
  const svgRef = useRef(null);

  // animated dash offset for pipes
  useEffect(() => {
    let t = 0;
    const id = setInterval(() => {
      t -= 1;
      if (svgRef.current) {
        svgRef.current.querySelectorAll('.flow-pipe').forEach(el => {
          el.style.strokeDashoffset = t;
        });
      }
    }, 40);
    return () => clearInterval(id);
  }, []);

  const boilerOk = data.boilerTemp < 345;
  const turbineOk = data.turbineOutput > 2500;
  const espOk = data.espEfficiency > 94;
  const conveyorOk = data.conveyorSpeed > 1.4;

  return (
    <div>
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 22, fontWeight: 400, fontFamily: 'var(--font-display)', color: 'var(--text)', marginBottom: 2 }}>Digital Twin</h1>
        <div style={{ fontSize: 12, color: 'var(--text-3)' }}>Live plant process visualization with real-time data overlay</div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 16 }}>
        <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: 24 }}>
          <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 16 }}>
            PROCESS FLOW DIAGRAM — UNIT 1
          </div>

          <svg ref={svgRef} viewBox="0 0 760 420" style={{ width: '100%', height: 'auto' }}>
            <defs>
              <marker id="arrow" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto">
                <path d="M0,0 L8,4 L0,8 Z" fill="rgba(255,255,255,0.2)" />
              </marker>
              <filter id="glow-amber">
                <feGaussianBlur stdDeviation="2" result="blur" />
                <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
              <filter id="glow-teal">
                <feGaussianBlur stdDeviation="2" result="blur" />
                <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
            </defs>

            {/* Background grid */}
            <rect width="760" height="420" fill="rgba(255,255,255,0.01)" rx="8" />
            <line x1="0" y1="0" x2="760" y2="0" stroke="rgba(255,255,255,0.03)" />
            {Array.from({ length: 12 }, (_, i) => (
              <line key={i} x1={i * 63} y1="0" x2={i * 63} y2="420" stroke="rgba(255,255,255,0.02)" />
            ))}
            {Array.from({ length: 7 }, (_, i) => (
              <line key={i} x1="0" y1={i * 60} x2="760" y2={i * 60} stroke="rgba(255,255,255,0.02)" />
            ))}

            {/* BIOMASS SILO */}
            <g transform="translate(30, 80)">
              <ellipse cx={40} cy={20} rx={35} ry={10} fill="#1e2530" stroke="rgba(232,162,75,0.4)" strokeWidth={1.5} />
              <rect x={5} y={20} width={70} height={100} fill="#1e2530" stroke="rgba(232,162,75,0.4)" strokeWidth={1.5} />
              <path d="M5,120 L20,150 L60,150 L75,120 Z" fill="#252d3a" stroke="rgba(232,162,75,0.4)" strokeWidth={1.5} />
              <ellipse cx={40} cy={20} rx={35} ry={10} fill="none" stroke="rgba(232,162,75,0.6)" strokeWidth={1} />
              <text x={40} y={80} textAnchor="middle" fill="var(--amber)" fontSize={10} fontFamily="var(--font-mono)" fontWeight={500}>BIOMASS</text>
              <text x={40} y={95} textAnchor="middle" fill="var(--text-3)" fontSize={8} fontFamily="var(--font-mono)">SILO</text>
              <StatusDot x={40} y={10} active={true} label="OK" />
            </g>

            {/* Conveyor */}
            <g transform="translate(110, 185)">
              <rect x={0} y={10} width={140} height={16} rx={8} fill="#1e2530" stroke="rgba(106,184,247,0.4)" strokeWidth={1.5} />
              <path className="flow-pipe" d="M10,18 L130,18" stroke="var(--sky)" strokeWidth={3} strokeDasharray="8,6" strokeLinecap="round" opacity={0.7} />
              <text x={70} y={6} textAnchor="middle" fill="var(--sky)" fontSize={9} fontFamily="var(--font-mono)">CONVEYOR</text>
              <StatusDot x={0} y={18} active={conveyorOk} label={`${data.conveyorSpeed.toFixed(1)} m/s`} />
            </g>

            {/* BOILER */}
            <g transform="translate(255, 110)">
              <rect x={0} y={0} width={120} height={140} rx={10} fill="#1e2530" stroke={boilerOk ? 'rgba(232,162,75,0.5)' : 'rgba(232,91,75,0.5)'} strokeWidth={2} />
              {/* Flame */}
              <path d="M30,130 Q35,100 50,110 Q45,85 60,95 Q55,70 75,80 Q80,60 90,70 Q95,95 80,100 Q90,115 85,130 Z"
                fill={boilerOk ? 'rgba(232,162,75,0.35)' : 'rgba(232,91,75,0.35)'}
                stroke={boilerOk ? 'var(--amber)' : 'var(--rose)'} strokeWidth={1}
                style={{ animation: 'blink 1.2s infinite' }}
              />
              <text x={60} y={25} textAnchor="middle" fill="var(--amber)" fontSize={11} fontFamily="var(--font-mono)" fontWeight={500}>BOILER</text>
              <text x={60} y={42} textAnchor="middle" fill="var(--text-3)" fontSize={9} fontFamily="var(--font-mono)">{data.boilerTemp.toFixed(1)}°C</text>
              <text x={60} y={56} textAnchor="middle" fill="var(--text-3)" fontSize={9} fontFamily="var(--font-mono)">{data.steamPressure.toFixed(1)} bar</text>
              <StatusDot x={110} y={70} active={boilerOk} label={boilerOk ? 'NORMAL' : 'HIGH TEMP'} />
            </g>

            {/* Steam pipe to turbine */}
            <path className="flow-pipe" d="M375,170 L450,170" stroke="rgba(106,184,247,0.8)" strokeWidth={4} strokeDasharray="10,6" fill="none" markerEnd="url(#arrow)" />
            <text x={412} y={160} textAnchor="middle" fill="var(--sky)" fontSize={8} fontFamily="var(--font-mono)">STEAM</text>

            {/* TURBINE */}
            <g transform="translate(450, 110)">
              <circle cx={65} cy={70} r={58} fill="#1e2530" stroke={turbineOk ? 'rgba(78,205,196,0.5)' : 'rgba(232,91,75,0.4)'} strokeWidth={2} />
              {/* Spinning blades */}
              {[0, 60, 120, 180, 240, 300].map((angle, i) => (
                <line key={i} x1={65} y1={70}
                  x2={65 + 42 * Math.cos((angle * Math.PI) / 180)}
                  y2={70 + 42 * Math.sin((angle * Math.PI) / 180)}
                  stroke={turbineOk ? 'rgba(78,205,196,0.7)' : 'rgba(232,91,75,0.5)'} strokeWidth={3} strokeLinecap="round"
                  style={{ transformOrigin: '65px 70px', animation: 'spin-slow 3s linear infinite' }}
                />
              ))}
              <circle cx={65} cy={70} r={12} fill="#252d3a" stroke={turbineOk ? 'var(--teal)' : 'var(--rose)'} strokeWidth={2} />
              <text x={65} y={14} textAnchor="middle" fill="var(--teal)" fontSize={10} fontFamily="var(--font-mono)" fontWeight={500}>TURBINE</text>
              <text x={65} y={145} textAnchor="middle" fill="var(--text-3)" fontSize={8} fontFamily="var(--font-mono)">{data.turbineOutput.toFixed(0)} kW</text>
              <StatusDot x={115} y={30} active={turbineOk} label="GEN" />
            </g>

            {/* Flue gas to ESP */}
            <path className="flow-pipe" d="M315,110 L315,60 L560,60" stroke="rgba(255,255,255,0.2)" strokeWidth={3} strokeDasharray="8,5" fill="none" />
            <text x={430} y={52} textAnchor="middle" fill="var(--text-3)" fontSize={8} fontFamily="var(--font-mono)">FLUE GAS</text>

            {/* ESP */}
            <g transform="translate(560, 30)">
              <rect x={0} y={0} width={90} height={60} rx={8} fill="#1e2530" stroke={espOk ? 'rgba(82,183,136,0.5)' : 'rgba(232,162,75,0.4)'} strokeWidth={1.5} />
              <text x={45} y={22} textAnchor="middle" fill="var(--jade)" fontSize={10} fontFamily="var(--font-mono)" fontWeight={500}>ESP</text>
              <text x={45} y={38} textAnchor="middle" fill="var(--text-3)" fontSize={8} fontFamily="var(--font-mono)">{data.espEfficiency.toFixed(1)}%</text>
              <StatusDot x={80} y={15} active={espOk} label="OK" />
            </g>

            {/* Ash to collector */}
            <path d="M605,90 L605,340" stroke="rgba(255,255,255,0.12)" strokeWidth={2} strokeDasharray="5,4" fill="none" />

            {/* ASH COLLECTOR */}
            <g transform="translate(560, 310)">
              <rect x={0} y={0} width={90} height={70} rx={8} fill="#1e2530" stroke="rgba(232,162,75,0.3)" strokeWidth={1.5} />
              <text x={45} y={22} textAnchor="middle" fill="var(--amber)" fontSize={10} fontFamily="var(--font-mono)" fontWeight={500}>ASH</text>
              <text x={45} y={36} textAnchor="middle" fill="var(--text-3)" fontSize={8} fontFamily="var(--font-mono)">COLLECTOR</text>
              <text x={45} y={52} textAnchor="middle" fill="var(--amber)" fontSize={9} fontFamily="var(--font-mono)">{data.ashCollection.toFixed(1)}%</text>
            </g>

            {/* CO2 Recovery */}
            <g transform="translate(670, 140)">
              <rect x={0} y={0} width={80} height={80} rx={8} fill="#1e2530" stroke="rgba(78,205,196,0.4)" strokeWidth={1.5} />
              <text x={40} y={22} textAnchor="middle" fill="var(--teal)" fontSize={10} fontFamily="var(--font-mono)" fontWeight={500}>CO₂</text>
              <text x={40} y={36} textAnchor="middle" fill="var(--text-3)" fontSize={8} fontFamily="var(--font-mono)">RECOVERY</text>
              <text x={40} y={56} textAnchor="middle" fill="var(--teal)" fontSize={12} fontFamily="var(--font-mono)">{data.co2Recovery.toFixed(1)}%</text>
            </g>

            {/* Distillation column */}
            <g transform="translate(255, 280)">
              <ellipse cx={60} cy={15} rx={50} ry={12} fill="#1e2530" stroke="rgba(82,183,136,0.4)" strokeWidth={1.5} />
              <rect x={10} y={15} width={100} height={80} fill="#1e2530" stroke="rgba(82,183,136,0.4)" strokeWidth={1.5} />
              <path className="flow-pipe" d="M110,55 L135,55" stroke="var(--jade)" strokeWidth={2} strokeDasharray="6,4" fill="none" />
              <text x={60} y={50} textAnchor="middle" fill="var(--jade)" fontSize={10} fontFamily="var(--font-mono)" fontWeight={500}>DISTILL.</text>
              <text x={60} y={65} textAnchor="middle" fill="var(--text-3)" fontSize={8} fontFamily="var(--font-mono)">COLUMN</text>
              <text x={60} y={80} textAnchor="middle" fill="var(--jade)" fontSize={9} fontFamily="var(--font-mono)">{data.ethanolProduction.toFixed(0)} L/hr</text>
            </g>

            {/* ETHANOL tank */}
            <g transform="translate(400, 290)">
              <ellipse cx={40} cy={12} rx={35} ry={9} fill="#1e2530" stroke="rgba(82,183,136,0.5)" strokeWidth={1.5} />
              <rect x={5} y={12} width={70} height={70} fill="#1e2530" stroke="rgba(82,183,136,0.5)" strokeWidth={1.5} />
              <text x={40} y={48} textAnchor="middle" fill="var(--jade)" fontSize={10} fontFamily="var(--font-mono)" fontWeight={500}>ETHANOL</text>
              <text x={40} y={63} textAnchor="middle" fill="var(--text-3)" fontSize={8} fontFamily="var(--font-mono)">STORAGE</text>
            </g>

            {/* Biomass to conveyor pipe */}
            <path className="flow-pipe" d="M70,195 L110,195" stroke="var(--amber)" strokeWidth={3} strokeDasharray="8,5" fill="none" />
          </svg>
        </div>

        {/* Component list */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ background: 'var(--ink-2)', border: '1px solid var(--border)', borderRadius: 14, padding: 20 }}>
            <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 14 }}>COMPONENT STATUS</div>
            {[
              { label: 'Biomass Feed', ok: true, val: `${data.biomassFlow.toFixed(1)} T/hr` },
              { label: 'Conveyor Belt', ok: conveyorOk, val: `${data.conveyorSpeed.toFixed(1)} m/s` },
              { label: 'Boiler Unit', ok: boilerOk, val: `${data.boilerTemp.toFixed(1)}°C` },
              { label: 'Steam Turbine', ok: turbineOk, val: `${data.turbineOutput.toFixed(0)} kW` },
              { label: 'ESP Filter', ok: espOk, val: `${data.espEfficiency.toFixed(1)}%` },
              { label: 'Ash Collector', ok: data.ashCollection > 90, val: `${data.ashCollection.toFixed(1)}%` },
              { label: 'CO₂ Recovery', ok: true, val: `${data.co2Recovery.toFixed(1)}%` },
              { label: 'Distillation', ok: true, val: `${data.ethanolProduction.toFixed(0)} L/h` },
              { label: 'DDGS Output', ok: true, val: `${data.ddgsOutput.toFixed(1)} T/h` },
            ].map(c => (
              <div key={c.label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 6, height: 6, borderRadius: '50%', background: c.ok ? 'var(--jade)' : 'var(--rose)', animation: 'blink 2s infinite' }} />
                  <span style={{ fontSize: 12, color: 'var(--text-2)' }}>{c.label}</span>
                </div>
                <span style={{ fontSize: 11, color: c.ok ? 'var(--text-2)' : 'var(--rose)', fontFamily: 'var(--font-mono)' }}>{c.val}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
