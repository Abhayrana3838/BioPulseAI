import { useState, useEffect, useRef } from 'react';

const BASE = {
  boilerTemp: 312,
  steamPressure: 18.4,
  turbineOutput: 2840,
  biomassFlow: 4.2,
  co2Recovery: 87.3,
  ethanolProduction: 142,
  ddgsOutput: 38,
  ashCollection: 94.1,
  conveyorSpeed: 1.8,
  espEfficiency: 96.7,
  fuelConsumption: 11.2,
};

function noise(val, spread) {
  return val + (Math.random() - 0.5) * spread;
}

export function useLiveData() {
  const [data, setData] = useState(BASE);
  const [history, setHistory] = useState(() =>
    Array.from({ length: 30 }, (_, i) => ({
      t: i,
      boilerTemp: noise(BASE.boilerTemp, 8),
      turbineOutput: noise(BASE.turbineOutput, 60),
      steamPressure: noise(BASE.steamPressure, 0.6),
      ethanolProduction: noise(BASE.ethanolProduction, 5),
    }))
  );
  const tickRef = useRef(30);

  useEffect(() => {
    const id = setInterval(() => {
      const next = {
        boilerTemp: Math.max(280, Math.min(360, noise(data.boilerTemp, 3))),
        steamPressure: Math.max(15, Math.min(24, noise(data.steamPressure, 0.3))),
        turbineOutput: Math.max(2400, Math.min(3200, noise(data.turbineOutput, 30))),
        biomassFlow: Math.max(3, Math.min(6, noise(data.biomassFlow, 0.15))),
        co2Recovery: Math.max(80, Math.min(96, noise(data.co2Recovery, 0.4))),
        ethanolProduction: Math.max(120, Math.min(165, noise(data.ethanolProduction, 2))),
        ddgsOutput: Math.max(30, Math.min(48, noise(data.ddgsOutput, 0.5))),
        ashCollection: Math.max(88, Math.min(99, noise(data.ashCollection, 0.3))),
        conveyorSpeed: Math.max(1.2, Math.min(2.5, noise(data.conveyorSpeed, 0.06))),
        espEfficiency: Math.max(92, Math.min(99.5, noise(data.espEfficiency, 0.2))),
        fuelConsumption: Math.max(9, Math.min(14, noise(data.fuelConsumption, 0.1))),
      };
      setData(next);
      setHistory(prev => {
        const point = {
          t: tickRef.current++,
          boilerTemp: next.boilerTemp,
          turbineOutput: next.turbineOutput,
          steamPressure: next.steamPressure,
          ethanolProduction: next.ethanolProduction,
        };
        return [...prev.slice(-49), point];
      });
    }, 1500);
    return () => clearInterval(id);
  }, [data]);

  return { data, history };
}

export function useAlerts(data) {
  const alerts = [];
  if (data.boilerTemp > 345) alerts.push({ id: 1, level: 'critical', msg: 'Boiler temperature exceeding safe threshold', system: 'Boiler' });
  if (data.steamPressure > 22) alerts.push({ id: 2, level: 'warning', msg: 'Steam pressure elevated — monitor closely', system: 'Steam System' });
  if (data.espEfficiency < 94) alerts.push({ id: 3, level: 'warning', msg: 'ESP efficiency below optimal range', system: 'ESP' });
  if (data.ashCollection < 90) alerts.push({ id: 4, level: 'critical', msg: 'Ash collection rate critical — check hoppers', system: 'Ash System' });
  return alerts;
}
