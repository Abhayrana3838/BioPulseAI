import React, { useState, useEffect, useRef } from 'react';

const ROLES = [
  { label: 'Plant Director', email: 'director@biopulse.in' },
  { label: 'Process Engineer', email: 'engineer@biopulse.in' },
  { label: 'Operations Lead', email: 'ops@biopulse.in' },
];

export default function LoginScreen({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [exiting, setExiting] = useState(false);
  const [tick, setTick] = useState(0);
  const canvasRef = useRef(null);
  const particlesRef = useRef([]);
  const animRef = useRef(null);

  // Particle canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize();
    window.addEventListener('resize', resize);

    // Init particles
    particlesRef.current = Array.from({ length: 55 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      r: Math.random() * 1.8 + 0.4,
      vx: (Math.random() - 0.5) * 0.25,
      vy: (Math.random() - 0.5) * 0.25,
      o: Math.random() * 0.4 + 0.1,
    }));

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const pts = particlesRef.current;
      // Draw connections
      for (let i = 0; i < pts.length; i++) {
        for (let j = i + 1; j < pts.length; j++) {
          const dx = pts[i].x - pts[j].x, dy = pts[i].y - pts[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 110) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(232,162,75,${(1 - dist / 110) * 0.12})`;
            ctx.lineWidth = 0.6;
            ctx.moveTo(pts[i].x, pts[i].y);
            ctx.lineTo(pts[j].x, pts[j].y);
            ctx.stroke();
          }
        }
      }
      pts.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(232,162,75,${p.o})`;
        ctx.fill();
      });
      animRef.current = requestAnimationFrame(draw);
    };
    draw();
    return () => { window.removeEventListener('resize', resize); cancelAnimationFrame(animRef.current); };
  }, []);

  // Ticker
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 2200);
    return () => clearInterval(id);
  }, []);

  const STATUS_LINES = [
    'BIOMASS FEED: ACTIVE — 4.2 T/HR',
    'BOILER PRESSURE: 18.4 BAR',
    'TURBINE OUTPUT: 2840 KW',
    'CO₂ RECOVERY: 87.3%',
    'ETHANOL YIELD: 142 L/HR',
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) { setError('Enter credentials to continue.'); return; }
    setLoading(true);
    setError('');
    await new Promise(r => setTimeout(r, 1400));
    setExiting(true);
    await new Promise(r => setTimeout(r, 600));
    onLogin({ email, role: ROLES.find(r => r.email === email)?.label || 'Engineer' });
  };

  return (
    <div style={{
      position: 'relative', width: '100vw', height: '100vh',
      background: 'radial-gradient(ellipse at 60% 40%, #171e28 0%, #0d1117 70%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      overflow: 'hidden',
      opacity: exiting ? 0 : 1,
      transform: exiting ? 'scale(1.04)' : 'scale(1)',
      transition: 'opacity 0.55s ease, transform 0.55s ease',
    }}>
      <canvas ref={canvasRef} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} />

      {/* Left info strip */}
      <div style={{
        position: 'absolute', left: 48, top: '50%', transform: 'translateY(-50%)',
        display: 'flex', flexDirection: 'column', gap: 10, opacity: 0.6,
      }}>
        {STATUS_LINES.map((line, i) => (
          <div key={i} style={{
            fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--amber)',
            letterSpacing: '0.12em', opacity: tick % 5 === i ? 1 : 0.4,
            transition: 'opacity 0.6s',
          }}>{line}</div>
        ))}
      </div>

      {/* Main card */}
      <div style={{
        position: 'relative', width: 420, zIndex: 10,
        background: 'rgba(30,37,48,0.85)',
        backdropFilter: 'blur(20px)',
        border: '1px solid rgba(232,162,75,0.18)',
        borderRadius: 20,
        padding: '44px 40px 40px',
        boxShadow: '0 32px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.06)',
        animation: 'float-up 0.7s ease both',
      }}>
        {/* Subtle grid overlay */}
        <div style={{
          position: 'absolute', inset: 0, borderRadius: 20, overflow: 'hidden', pointerEvents: 'none',
          backgroundImage: 'linear-gradient(rgba(232,162,75,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(232,162,75,0.03) 1px, transparent 1px)',
          backgroundSize: '28px 28px',
        }} />

        {/* Logo */}
        <div style={{ marginBottom: 32, position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 6 }}>
            <div style={{
              width: 38, height: 38, borderRadius: 10,
              background: 'linear-gradient(135deg, var(--amber) 0%, #c47e2a 100%)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 18, fontWeight: 700, color: '#0d1117',
              boxShadow: '0 4px 16px var(--amber-glow)',
            }}>B</div>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, color: 'var(--text)', letterSpacing: '-0.01em' }}>BioPulse AI</div>
              <div style={{ fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>Industrial Intelligence Platform</div>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#52b788', display: 'inline-block', animation: 'blink 2s infinite' }} />
            <span style={{ fontSize: 10, color: 'var(--jade)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em' }}>PLANT SYSTEMS ONLINE</span>
          </div>
        </div>

        <div style={{ marginBottom: 28 }}>
          <div style={{ fontSize: 20, fontWeight: 500, color: 'var(--text)', marginBottom: 4 }}>Sign in</div>
          <div style={{ fontSize: 13, color: 'var(--text-2)' }}>Access your plant intelligence dashboard</div>
        </div>

        {/* Quick-select roles */}
        <div style={{ marginBottom: 20, display: 'flex', gap: 8 }}>
          {ROLES.map(r => (
            <button key={r.email} onClick={() => { setEmail(r.email); setPassword('biopulse2024'); }}
              style={{
                flex: 1, padding: '6px 4px', borderRadius: 8,
                border: `1px solid ${email === r.email ? 'var(--amber)' : 'var(--border)'}`,
                background: email === r.email ? 'var(--amber-dim)' : 'transparent',
                color: email === r.email ? 'var(--amber)' : 'var(--text-3)',
                fontSize: 10, fontFamily: 'var(--font-mono)', letterSpacing: '0.06em',
                transition: 'var(--transition)', cursor: 'pointer',
              }}>
              {r.label.split(' ')[0].toUpperCase()}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <span style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Work Email</span>
            <input value={email} onChange={e => setEmail(e.target.value)}
              placeholder="name@biopulse.in" type="email"
              style={{
                background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)',
                borderRadius: 9, padding: '11px 14px', color: 'var(--text)',
                fontSize: 14, outline: 'none', transition: 'border-color 0.2s',
              }}
              onFocus={e => e.target.style.borderColor = 'rgba(232,162,75,0.5)'}
              onBlur={e => e.target.style.borderColor = 'var(--border)'}
            />
          </label>

          <label style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <span style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', textTransform: 'uppercase' }}>Password</span>
            <input value={password} onChange={e => setPassword(e.target.value)}
              placeholder="••••••••••" type="password"
              style={{
                background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)',
                borderRadius: 9, padding: '11px 14px', color: 'var(--text)',
                fontSize: 14, outline: 'none', transition: 'border-color 0.2s',
              }}
              onFocus={e => e.target.style.borderColor = 'rgba(232,162,75,0.5)'}
              onBlur={e => e.target.style.borderColor = 'var(--border)'}
            />
          </label>

          {error && <div style={{ fontSize: 12, color: 'var(--rose)', padding: '8px 12px', background: 'var(--rose-dim)', borderRadius: 7, border: '1px solid rgba(232,91,75,0.2)' }}>{error}</div>}

          <button type="submit" disabled={loading}
            style={{
              marginTop: 6, padding: '13px 20px', borderRadius: 10,
              background: loading ? 'rgba(232,162,75,0.5)' : 'var(--amber)',
              color: '#0d1117', fontWeight: 600, fontSize: 14,
              letterSpacing: '0.02em',
              boxShadow: loading ? 'none' : '0 4px 20px var(--amber-glow)',
              transition: 'var(--transition)', cursor: loading ? 'wait' : 'pointer',
              position: 'relative', overflow: 'hidden',
            }}>
            {loading ? (
              <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                <span style={{ width: 14, height: 14, border: '2px solid rgba(13,17,23,0.4)', borderTopColor: '#0d1117', borderRadius: '50%', display: 'inline-block', animation: 'spin-slow 0.7s linear infinite' }} />
                Authenticating…
              </span>
            ) : 'Access Platform'}
          </button>
        </form>

        <div style={{ marginTop: 20, paddingTop: 20, borderTop: '1px solid var(--border)', fontSize: 11, color: 'var(--text-3)', textAlign: 'center' }}>
          Demo: select a role above — password auto-fills
        </div>
      </div>

      {/* Bottom bar */}
      <div style={{
        position: 'absolute', bottom: 24, left: '50%', transform: 'translateX(-50%)',
        display: 'flex', alignItems: 'center', gap: 20,
        fontSize: 10, color: 'var(--text-3)', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em',
        whiteSpace: 'nowrap',
      }}>
        <span>BIOPULSE v2.4</span>
        <span style={{ width: 3, height: 3, borderRadius: '50%', background: 'var(--text-3)' }} />
        <span>HARYANA PLANT — UNIT 1</span>
        <span style={{ width: 3, height: 3, borderRadius: '50%', background: 'var(--text-3)' }} />
        <span>SECURE CHANNEL</span>
      </div>
    </div>
  );
}
