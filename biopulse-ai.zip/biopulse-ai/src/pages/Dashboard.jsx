import React, { useState } from 'react';
import Sidebar from '../components/Sidebar';
import TopBar from '../components/TopBar';
import Overview from '../components/Overview';
import DigitalTwin from '../components/DigitalTwin';
import PredictiveMaintenance from '../components/PredictiveMaintenance';
import AIAssistant from '../components/AIAssistant';
import SupplyChain from '../components/SupplyChain';
import CarbonAnalytics from '../components/CarbonAnalytics';
import Forecasting from '../components/Forecasting';
import { useLiveData, useAlerts } from '../hooks/useLiveData';

const PANELS = ['overview', 'twin', 'maintenance', 'assistant', 'supply', 'carbon', 'forecast'];

export default function Dashboard({ user, onLogout }) {
  const [active, setActive] = useState('overview');
  const { data, history } = useLiveData();
  const alerts = useAlerts(data);

  const renderPanel = () => {
    switch (active) {
      case 'overview': return <Overview data={data} history={history} alerts={alerts} />;
      case 'twin': return <DigitalTwin data={data} />;
      case 'maintenance': return <PredictiveMaintenance data={data} />;
      case 'assistant': return <AIAssistant data={data} />;
      case 'supply': return <SupplyChain data={data} />;
      case 'carbon': return <CarbonAnalytics data={data} history={history} />;
      case 'forecast': return <Forecasting data={data} />;
      default: return null;
    }
  };

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: 'var(--ink)' }}>
      <Sidebar active={active} setActive={setActive} alerts={alerts} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        <TopBar user={user} onLogout={onLogout} alerts={alerts} data={data} />
        <main style={{ flex: 1, overflow: 'auto', padding: '24px 28px', background: 'var(--ink)' }}>
          {renderPanel()}
        </main>
      </div>
    </div>
  );
}
